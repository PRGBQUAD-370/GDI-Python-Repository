Credit's to PRGBQUAD-370 from github this is all safe unless your PC has very bad VRAM which most users can run without having issues
DO NOT RUN  IT IF YOU HAVE EPILPSE